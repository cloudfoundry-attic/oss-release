def test_add():
    assert 1 + 2 == 3, "bad add"

def test_sub():
    assert 2 - 1 == 1, "bad sub"

def test_sub_fail():
    assert 2 - 2 == 1, "bad sub"
