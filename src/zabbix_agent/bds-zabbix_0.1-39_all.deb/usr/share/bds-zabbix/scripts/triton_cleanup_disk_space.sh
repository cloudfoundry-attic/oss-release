#!/bin/bash
#
# Pedro Gonzalez
# pedrog@mozy.com
# Nov 2011
#
# Usage: triton_cleanup_disk_space.sh
# No parameters
#
# Script Summary:
# Free up space for TDS's and TDN's.
# Checks /tmp/ctriton for core dump files, removes old files and leaves only the latest file.
# Checks triton logs, rotates files, removes old logs leaving only one week of logs (7 files).
# Checks status-o-matic and status-o-matic-sync rotate files and removes all old files


# PROCESS CORE DUMP FILEs

LOGFILE="triton_cleanup_disk_space.log"
DISK="/tmp"
EXIT_CD=0

# Log to file function
function log {
        echo \[`date +"%Y-%m-%d %T"`\] \[`hostname`\] $1 >> $LOGFILE
}

log "Starting disk cleanup..."

# Check if we have core dump files to leave the latest one
if [ `ls "$DISK"/ctriton | wc -l` -gt "0" ]
then
   log "Core dump files exist, removing all but latest"

   nf=(`ls -t "$DISK"/ctriton | head -1`) # Get latest core dump file name
   find "$DISK"/ctriton -not \( -name $nf \)  -exec rm {} \; 2>/dev/null # Leave only the latest core dump file

   # Check if root and /tmp are using different partition to check if the problem is fixed
   if mountpoint -q $DISK
   then
     log "Partition /tmp exists..."

     # Check if space in /tmp partition is greater than 80%
     if [ `(df | grep -w "$DISK" | awk '{print $5 } ' | sed '$s/.$//')` -ge "80" ]
     then
        log "/tmp > 80% used, removing all core dump files"

        rm "$DISK"/ctriton/"$nf" 2>/dev/null # Unfortunately we need to remove all files
        if [ `(df | grep -w "$DISK" | awk '{print $5 } ' | sed '$s/.$//')` -ge "80" ]
        then
           log "WARNING: /tmp still > 80% used"
           
           EXIT_CD=1 # If not, will return 1 to keep the ticket open and manually check
        fi
     fi
   fi
fi


DISK="/"

# ROTATE TRITON LOGS, KEEP 1WK
if  [ -f /var/log/triton.log ]
then
   log "/var/log/triton.log exists, rotating"

   logrotate -f /etc/logrotate.d/ctriton-config > /dev/null
   ls /var/log/triton.???.*.gz | awk -F . '{if($3 > 7) system("rm "$0)}'
fi

# REMOVE STATUS-O-MATIC LOGS
if [ -f /var/log/status-o-matic/twistd.log ]
then
   log "/var/log/status-o-matic/twistd.log exists, removing"

   if /etc/init.d/status-o-matic restart 1>/dev/null 2>/dev/null
   then 
      rm /var/log/status-o-matic/twistd.log.* 2> /dev/null
   fi
fi    
 
# REMOVE STATUS-O-MATIC-SYNC LOGS
if [ -f /var/log/status-o-matic-sync/twistd.log ]
then
   log "/var/log/status-o-matic-sync/twistd.log exists, removing"

   if /etc/init.d/status-o-matic-sync restart 1>/dev/null 2>/dev/null
   then 
      rm /var/log/status-o-matic-sync/twistd.log.* 2> /dev/null
   fi
fi    

# CHECK IF THE PROBLEM WAS FIXED 
if [ `(df | grep -w "$DISK" | awk '{print $5 } ' | sed '$s/.$//')` -ge "80" ]
then
   log "WARNING" $DISK "partition still > 80, exiting"

   EXIT_CD=1 # Return 1 to keep the ticket open and manually check
fi

exit $EXIT_CD

