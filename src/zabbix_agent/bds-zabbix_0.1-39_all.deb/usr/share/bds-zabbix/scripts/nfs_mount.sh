#!/bin/bash
#
# Floyd Arguello farguello@vmware.com
#
# nfs_mount.sh
# check that nfs mountpoints are mounted and writeable
#

set -e
set -u

DISK=$1
STATUS=$(mountpoint -q $DISK; echo $?)

# check if directory
if [ -d "$DISK" ]; then
        # exit if not mounted
        if [ "$STATUS" -ne "0" ]; then
                echo "not mounted"
                exit
        fi

        # test construct - return success if mounted and writeable, assume read-only if write fails
        # as script would have exited if disk not mounted
        [[ ( "$STATUS" -eq "0" ) && ( -w "$DISK" ) ]] && echo "success" || echo "mounted read-only"
else
        echo "doesn't exist"
fi
