#!/bin/bash

state=`grep "disk: $1" /tmp/tdn_status_disk.txt | awk '{print $7}'`

case "$2" in 
        avail)
        if [ $state == "ERROR" ]; then
                val="11"
        else
                val="10"
        fi
        value=`grep "disk: $1" /tmp/tdn_status_disk.txt | cut -d: -f $val | cut -f 2 -d" "`
        echo $value
        ;;
        free)
        if [ $state == "ERROR" ]; then
                val="9"  
        else
                val="8"  
        fi
        value=`grep "disk: $1" /tmp/tdn_status_disk.txt | cut -d: -f $val | cut -f 2 -d" "`
        echo $value
        ;;
        resvd)
        if [ $state == "ERROR" ]; then
                val="10"  
        else
                val="9"  
        fi
        value=`grep "disk: $1" /tmp/tdn_status_disk.txt | cut -d: -f $val | cut -f 2 -d" "`
        echo $value
        ;;
        locates)
        if [ $state == "ERROR" ]; then
                val="15" 
        else
                val="14"  
        fi
        value=`grep "disk: $1" /tmp/tdn_status_disk.txt | cut -d: -f $val | sed -e 's/\///g' | cut -d" " -f 2`
        echo $value
        ;;
        await)
         if [ $state == "ERROR" ]; then
                val="17"
        else
                val="16"
        fi
        value=`grep "disk: $1" /tmp/tdn_status_disk.txt | cut -d: -f $val | cut -d" " -f 2`
        echo $value
        ;;
esac
