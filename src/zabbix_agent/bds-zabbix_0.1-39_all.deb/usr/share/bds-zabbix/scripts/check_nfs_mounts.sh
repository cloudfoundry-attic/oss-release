#!/bin/bash
PROGNAME=$(basename $0)
RUNPATH=$(dirname $0)
SHOWMOUNT="/sbin/showmount"
LS="/bin/ls"
TIMEOUT="$RUNPATH/timeout"

for APP in {$LS,$SHOWMOUNT,$TIMEOUT}; do
	if [ ! -x $APP ]; then
		echo "'$APP' is not exectuable. Cannot continue." 
		exit 2
	fi
done

ERRORSERVER=""
ERRORMOUNT=""
for SERVER in $(grep -e "[[:space:]]nfs[[:space:]]" /etc/fstab | grep -ve "^#" | awk -F: '{print $1}' | sort | uniq); do
        $SHOWMOUNT -e $SERVER >/dev/null 2>/dev/null #don't care about output, just return status.
        if [ "$?" == "1" ]; then
                ERRORSERVER="$ERRORSERVER\t$SERVER\n"
        else
                for MOUNTPOINT in $(grep -e "[[:space:]]nfs[[:space:]]" /etc/fstab | grep -ve "^#" | grep $SERVER: | awk '{print $2}'); do
			$TIMEOUT 3 $LS $MOUNTPOINT >/dev/null 2>&1; RET=$?
			if [ "$RET" -ne "0" ]; then
				ERRORMOUNT="$ERRORMOUNT\t$MOUNTPOINT\n"
			fi
                done
        fi
done

if [[ -n "$ERRORSERVER" || -n "$ERRORMOUNT" ]]; then
        echo "WARNING: some nfs checks failed."
        echo -e "$ERRORSERVER$ERRORMOUNT"
        exit 1
fi

echo "OK";
exit 0;
