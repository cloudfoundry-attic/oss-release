#!/bin/bash

if [ -z "$1" ]; then
	echo "Must provide a filename." >&2
	exit 1
fi

if [ ! -e "$1" ]; then
	echo "The file \"$1\" does not exist." >&2
	exit 2
fi

echo $((($(date +%s) - $(stat -c %Y $1)) /60/60))
